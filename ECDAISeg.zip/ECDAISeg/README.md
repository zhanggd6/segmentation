1. 训练
1.1 将数据集放入VOCdevkit中。  
1.2 在train.py中设置对应参数。  
1.3 运行train.py进行训练。  
  
2. 预测
修改deeplab.py的backbone和model_path之后再运行predict.py可完成预测。           

3. 结果评估
运行get_miou.py即可获得miou大小。  



1. Training
1.1 Put the dataset into VOCdevkit.
1.2 Set the corresponding parameters in train.py.
1.3 Run train.py for training.
  
2. Prediction
Modify the backbone and model_path of deeplab.py and then run predict.py to complete the prediction.

3. Result evaluation
Run get_miou.py to get the miou size.