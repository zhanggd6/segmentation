import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from nets.base_model import BaseModel
from nets.helpers import initialize_weights
from itertools import chain
from nets.convnext import convnext_tiny
from nets.uafm import UAFM
from nets.cpm3 import MCS



class UperNet(BaseModel):
    # Implementing only the object path
    def __init__(self, num_classes, pretrained=True, fpn_out=48,
                 freeze_bn=False, **_):
        super(UperNet, self).__init__()
        feature_channels = [96, 192, 384, 768]
        self.backbone = convnext_tiny(pretrained=pretrained)
        #self.PPN = PSPModule(feature_channels[-1])
        self.CPM = MCS(c1=feature_channels[-1])

        self.conv = nn.Sequential(
            nn.Conv2d(feature_channels[-1], feature_channels[2], kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(feature_channels[2]),
            nn.ReLU(inplace=True)
        )

        self.uafm_spatten1 = UAFM(x_ch=384, y_ch=384, out_ch=192)
        self.uafm_spatten2 = UAFM(x_ch=192, y_ch=192, out_ch=96)
        self.uafm_spatten3 = UAFM(x_ch=96, y_ch=96, out_ch=48)

        self.conv_fusion = nn.Sequential(
            nn.Conv2d(384+192+96+48, fpn_out, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(fpn_out),
            nn.ReLU(inplace=True)
        )

        #self.FPN = FPN_fuse(feature_channels, fpn_out=fpn_out)
        self.head = nn.Conv2d(48, num_classes, kernel_size=1, stride=1)


    def forward(self, x):
        input_size = (x.size()[2], x.size()[3])
        p = []
        features = self.backbone(x)
        x = self.CPM(features[-1])


        p.append(x)
        x = self.uafm_spatten1(features[2], x)
        p.append(x)
        x = self.uafm_spatten2(features[1], x)
        p.append(x)
        x = self.uafm_spatten3(features[0], x)
        p.append(x)
        H,W = p[-1].size()[2],p[-1].size()[3]
        p[0:3] = [F.interpolate(feature, size=(H, W), mode='bilinear', align_corners=True) for feature in p[0:3]]
        x = self.conv_fusion(torch.cat((p), dim=1))
        #x = self.head(self.FPN(features))
        x = self.head(x)

        x = F.interpolate(x, size=input_size, mode='bilinear')
        return x


if __name__ == '__main__':
    from torchsummary import summary
    data = torch.randn(4,3,512,512)
    a = UperNet(num_classes=21, pretrained=True)
    s = a(data)
    print(s.shape)
    # for i in range(4):
    #     print(s[i].shape)