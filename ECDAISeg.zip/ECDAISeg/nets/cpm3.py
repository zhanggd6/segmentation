import torch
from torch import nn






class Conv(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=0, g=1):  # ch_in, ch_out, kernel, stride, padding, groups
        super(Conv, self).__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def fuseforward(self, x):
        return self.act(self.conv(x))


class DPUP(nn.Module):
    def __init__(self,c1,kernal=(1,1)):
        super().__init__()
        self.dp = nn.AdaptiveAvgPool2d(kernal[0])
        self.conv = Conv(c1, 384, k=1)
        self.up = nn.Upsample(size=(16,16), mode='bilinear' )

    def forward(self,x):
        x = self.dp(x)
        x = self.conv(x)
        x = self.up(x)
        return x

class MCS(nn.Module):
    def __init__(self,c1):
        super().__init__()
        self.dp1 = DPUP(c1,kernal=(1,1))
        self.dp2 = DPUP(c1,kernal=(2,2))
        self.dp3 = DPUP(c1,kernal=(4,4))
        self.dp4 = DPUP(c1,kernal=(8,8))


        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=3, padding=1, bias=False)
        self.sigmoid = nn.Sigmoid()
        self.conv1 = Conv(768, 384, k=1)
        self.conv2 = Conv(1920, 1536, k=1)
        self.conv6 = Conv(384, 384, k=1)
        self.conv7 = nn.Conv2d(384,384,1,1,0)

    def forward(self,x):
        dep1 = self.dp1(x)
        dep2 = self.dp2(x)
        dep3 = self.dp3(x)
        dep4 = self.dp4(x)
        dep5 = self.conv1(x)
        out = torch.cat([dep1,dep2,dep3,dep4,dep5], dim=1)
        out = self.conv2(out)

        y = self.avg_pool(out)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)

        y = self.sigmoid(y)
        #out2 = x * y.expand_as(x)     #扩展y为与x相同形状的张量

        result = y[:,:384,...].expand_as(dep1) * dep1 + y[:,384:768,...].expand_as(dep2) * dep2 + y[:,768:1152,...].expand_as(dep3) * dep3+ y[:,1152:1536,...].expand_as(dep4) * dep4
        # z1 = out2[:, :384, ...] * dep1
        # z2 = out2[:, :384:768, ...] * dep2
        # z3 = out2[:, :768:1152, ...] * dep3
        # z4 = out2[:, :1152:1536, ...] * dep4
        # result = z1 + z2 + z3 + z4
        result = self.conv7(result)
        return result


if __name__ == '__main__':
    from torchsummary import summary
    data = torch.randn(4,768,16,16)
    a = MCS(c1=768)
    s = a(data)
    print(s.shape)